import java.math.BigDecimal;
import java.text.DecimalFormat;

import javax.swing.JOptionPane;

/**
 * Clase principal del proyecto Clase 1 del curso Java Standard
 * 
 * @author carlos.
 */
public class Clase01 {

	/**
	 * Punto de entrada del proyecto.
	 * 
	 * @param args argumentos que ingresan de consola.
	 */
	public static void main(String[] args) {
		/*
		 * Curso: Java Standard Web Programing 11 40 hs Días: Sábado 10:00 a 14:00 hs
		 * Profe: Carlos Ríos carlos.rios@educacionit.com Materiales:
		 * alumni.educacionit.com github: https://github.com/crios2020/JavaSEFebrero
		 * Software: JDK y IDE
		 * 
		 * JDK: Java Development Kit
		 * 
		 * JDK: Oracle o RedHat o Eclipse (AdoptJ9) ....
		 * 
		 * LTS: Long Term Support 8 años.
		 * 
		 * Versiones LTS (Se liberan cada 3 años) JDK 8, 11, 17
		 * 
		 * IDE: Eclipse - Spring Tools Suite - IntelliJ IDEA - NetBeans
		 * 
		 * 
		 */
		System.out.println("Hola Mundo!!");
		System.out.println("Versión JDK: " + System.getProperty("java.version"));
		// syso + ctrol + space : atajo de teclado System.out.println() en Ecplise
		// sout + tab : atajo de teclado System.out.println() en netbeans

		// Linea de comentarios

		/*
		 * Bloque De Comentarios
		 */

		/**
		 * Comentarios JAVA DOC. Se debe colocar delante de la declaración de clase o
		 * método. Es Visible por fuera del Ejecutable.
		 */

		// Tipo de datos primitivos.
		// Java es un lenguaje de tipado fuerte.

		// Tipo de datos enteros.
		// Tipo de datos boolean 0 1 1 byte
		boolean bo = true;
		System.out.println(bo);
		bo = false;
		System.out.println(bo);

		// Tipo de datos byte 1 byte
		byte by = -128;
		by = 0;
		by = 127;
		System.out.println(by);

		// Tipo de datos short 2 bytes
		short sh = 32000;
		System.out.println(sh);

		// Tipo de datos int; 4 bytes
		int in = 2000000000;
		System.out.println(in);

		// Tipo de datos Long 8 bytes
		long lo = 3000000000L;
		System.out.println(lo);

		// Tipo de datos char 2 bytes
		char ch = 65;
		System.out.println(ch);
		ch += 32;
		System.out.println(ch);
		ch = 't';
		System.out.println(ch);

		// Tipo de datos de punto flotante

		// tipo de datos float 32 bits
		float fl = 8.25f;
		System.out.println(fl);

		// tipo de datos double 64 bits
		double dl = 8.25;
		System.out.println(dl);

		fl = 10;
		dl = 10;

		System.out.println(fl / 3);
		System.out.println(dl / 3);

		fl = 100;
		dl = 100;

		System.out.println(fl / 3);
		System.out.println(dl / 3);

		// La clase String
		String st = "Hola";
		System.out.println(st);
		System.out.println(st.length());
		// st.value[1]=65;

		/*
		 * JDK 9 o inferior private final char[] value; String st="Hola"; 8 bytes
		 * 
		 * JDK 10 o sup private final byte[] value; String st="Hola"; 4 bytes
		 */

		// Tipo de datos var JDK 9 o sup.
		var var1 = "Hola"; // String
		// var1=30; // error
		var var2 = true; // boolean
		var var3 = 30; // int
		var var4 = 30L; // long
		var var5 = Integer.parseInt("30"); // int
		var var6 = 'G'; // char
		var var7 = 2.65; // double
		var var8 = 2.65D; // double
		var var9 = 2.65f; // float

		// DecimalFormat
		double precio = 200000.90;
		var precio2 = 20000000.90;

		System.out.println(precio);
		System.out.println(precio2);

		DecimalFormat df = new DecimalFormat("###,###,###.00");
		System.out.println(df.format(precio));
		System.out.println(df.format(precio2));

		// BigDecimal
		BigDecimal bg = new BigDecimal("1000000000");

		// String
		String texto = "Esto es un mensaje de texto!";
		System.out.println(texto);

		// recorrer el vector texto.
		for (int a = 0; a < texto.length(); a++) System.out.print(texto.charAt(a));
		System.out.println();

		// imprimir texto en mayusculas
		for (int a = 0; a < texto.length(); a++) {
			char car=texto.charAt(a);
			if(car>=97 && car<=122) car-=32;
			System.out.print(car);
		}
		System.out.println();
		
		// Operador Ternario ?
		for (int a = 0; a < texto.length(); a++) {
			char car=texto.charAt(a);
			System.out.print((car>=97 && car<=122)?car-=32:car);
		}
		System.out.println();

		// imprimir texto en minusculas
		for (int a = 0; a < texto.length(); a++) {
			char car=texto.charAt(a);
			System.out.print((car>=65 && car<=90)?car+=32:car);
		}
		System.out.println();
		
		System.out.println(texto.toUpperCase());
		System.out.println(texto.toLowerCase());
		
		JOptionPane.showMessageDialog(null,"Hola a todos!");
		
		
	}

}