
//Declaración de clase
public class Auto {
	
	//Declaración de atributos
	String marca;
	String modelo;
	String color;
	int velocidad;
	
	//Métodos constructores
	
	/**
	 * Este método fue deprecado por Carlos Ríos el 13/02/2021 
	 * por resultar inseguro.
	 * usar en su reemplazo Auto(String marca, String modelo, String color)
	 */
	@Deprecated
	Auto(){} 	//constructor vacio.
	
	Auto(String marca, String modelo, String color){
		this.marca = marca;
		this.modelo = modelo;
		this.color = color;
	}
	
	//Declaración de métodos
	void acelerar() { 											//acelerar
		//velocidad+=10; 
		//if(velocidad>100) velocidad=100;
		acelerar(10);		//Llamado a método de la misma clase.
	}
	
	//Método sobrecargado
	void acelerar(int kilometros) {								//acelerarInt
		velocidad+=kilometros;
		if(velocidad>100) velocidad=100;
	}
	
	void acelerar(int t,int x) {}								//acelerarIntInt
	
	void acelerar(String x,int v) {}							//acelerarStringInt
	
	void frenar() { velocidad-=10; }
	
	void imprimirVelocidad() {
		System.out.println(velocidad);
	}
	
	//Método con devolución de parámetro
	int getVelocidad() {
		//System.out.println("*");
		return this.velocidad;		//return devuelve y finaliza el método.
		//System.out.println("*");
	}
	
	@Override
	public String toString() {
		return this.marca+" "+this.modelo+" "+this.color+" "+this.velocidad;
	}
	
} //end class
