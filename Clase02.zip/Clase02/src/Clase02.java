import javax.swing.JOptionPane;

public class Clase02 {

	public static void main(String[] args) {
		//El método main es ejecutable y puede ser punto de entrada
		//de un proyecto.
		
		System.out.println("Proyecto Clase 02!");
		
		/*
			Paradigma de la programación Orientada a Objetos
			
			Clase:	Una clase es todo lo que se encuentra en forma sustantiva.
					Se declara con la primer letra en mayúscula y el nombre de clase en 
					singular. Ej: Cliente, Articulo, Proveedor, Factura, Vendedor.
					Una clase es una plantilla que representa una idea genérica de la realidad.
					Una clase permite que creemos objetos y cada objeto tiene un estado propio
					y representa una situación en particular.
			
			En java las clases son objetos de la clase Class. La clase Class sirve para representar
			todas las clases.
			
			Atributos:	Los atributos describen a la clase, (son Adjetivos). Son variables 
						contenidas dentro de una clase. Tiene un tipo de datos asociado.
						Las clases declaran atributos y los objetos asignan el estado.
						
			En java los atributos son objetos de la clase java.lang.reflect.Field
			
			Los atributos tienen un proceso de inicialización automatica.
			Los atributos String se inicializan en null.
			Los atributos númericos se inicializan en 0.
			
			
			Métodos: Son acciones que realiza la clase y se detectan como verbos.
						Opcionalmente puede tener parametros de entrada y salida.
						
			En java los métodos son objetos de la clase java.lang.reflect.Method
			
			
			Objetos: Son instancias de la clase, representan una situación en particular.
					Tienen estado propio (Valor de atributos propio)
					
			Sobrecarga de Métodos: Hay sobrecarga cuando en una clase existen métodos con el
				mismo nombre, pero diferente firma de parámetros de entrada.
				
			
			Métodos constructores: Son métodos que inicializan los objetos. 
					No posee devolución de parámetros.
					Pueden ser sobrecargados, tienen el mismo nombre que la clase
					y se invoca automáticamente con la palabra clave new.
					Cuando una clase no tiene constructores declarados, java agrega un
					constructor vació en tiempo de compilación.
	
			Devolución de parámetros: Los métodos pueden devolver un parámetro y solo uno.
				El parámetro devuelto, pertenece a un tipo de datos asociado.
				void (vacio) significa que el método no devuelve valor.
			
			ToString()
			

		 */
		
		System.out.println("-- auto1 --");
		Auto auto1=new Auto();	//new Auto() invoka al método constructor
		
		auto1.marca="Fiat";
		auto1.modelo="Toro";
		auto1.color="Blanco";
		
		auto1.acelerar();			//10
		auto1.acelerar();			//20
		auto1.acelerar();			//30
		auto1.frenar();				//20 
		auto1.acelerar(16); 		//36
		
		System.out.println(auto1.marca+" "+auto1.modelo+" "+auto1.color+" "+auto1.velocidad);
		
		
		//int x;
		//System.out.println(x);	//Error las variables deben ser inicializadas.
		
		System.out.println("-- auto2 --");
		Auto auto2=new Auto();
		auto2.marca="VW";
		auto2.modelo="UP";
		auto2.color="Rojo";
		
		for(int a=0;a<=60;a++) auto2.acelerar();
		
		System.out.println(auto2.marca+" "+auto2.modelo+" "+auto2.color+" "+auto2.velocidad);
		
		
		System.out.println("-- auto3 --");
		Auto auto3=new Auto("VW","Gol","Negro");
		auto3.acelerar(23);
		//auto3.velocidad=300;
		
		auto3.imprimirVelocidad();
		
		System.out.println(auto3.getVelocidad());
		
		//JOptionPane.showMessageDialog(null, "Velocidad: "+auto3.getVelocidad());
		
		//método .toString()	(Object)
		System.out.println(auto3.toString());
		System.out.println(auto3);
		
		System.out.println("-- empleado1 --");
		Empleado empleado1=new Empleado(1,"Lorena","Salas",20000);
		//System.out.println(empleado1.nombre);
		//empleado1.sueldoBasico=999999999;
		empleado1.setSueldoBasico(99999999);
		
		System.out.println(empleado1);
		
		/*
				Modificadores de visibilidad
				
		Modificador				Alcance
		default (Omitido)		Ese miembro de clase, es accesible desde la misma clase y
								desde clases del mismo paquete.
								
		public					Es accesible desde la misma clase y desde cualquier clase 
								de cualquier paquete.
		
		private 				Solo es accesible desde la misma clase.
		
		protected				Es accesible desde la misma clase y desde clases hijas
								y desde clases del mismo paquete.
		
		 */
		
	}

}
