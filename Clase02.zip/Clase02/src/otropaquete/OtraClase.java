package otropaquete;


public class OtraClase {
	public static void main(String[] args) {

	}
}
