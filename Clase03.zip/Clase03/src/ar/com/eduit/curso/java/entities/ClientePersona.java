package ar.com.eduit.curso.java.entities;

public class ClientePersona {
    private int nro;
    private String nombre;
    private int edad;
    private Cuenta cuenta;
  
    public ClientePersona(int nro, String nombre, int edad){
        //Este constructor permite crear un cliente sin cuenta.
        this.nro = nro;
        this.nombre = nombre;
        this.edad = edad;  
    }

    public ClientePersona(int nro, String nombre, int edad, Cuenta cuenta){
        //Este constructor crea un cliente con cuenta.
        //Se ingresa como parametro un objeto cuenta ya existente
        //Una cuenta puede pertenecer a más de un cliente
        this.nro = nro;
        this.nombre = nombre;
        this.edad = edad; 
        this.cuenta = cuenta;
    }
    
    public ClientePersona(int nro, String nombre, int edad, int nroCuenta, String moneda){
        //Este constructor crea un cliente con cuenta.
        //El constructor le crea una cuenta propia.
        this.nro = nro;
        this.nombre = nombre;
        this.edad = edad;
        this.cuenta = new Cuenta(nroCuenta, moneda);
    }

    public void comprar(){
        System.out.println("El cliente persona realiza una compra!");
    }
    
    @Override
    public String toString() {
        return "ClientePersona{" + "nro=" + nro + ", nombre=" + nombre + ", edad=" + edad + ", cuenta=" + cuenta + '}';
    }

    public int getNro() {
        return nro;
    }

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    public Cuenta getCuenta() {
        return cuenta;
    }
    
}