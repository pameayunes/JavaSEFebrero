package ar.com.eduit.curso.java.entities;

public final class Cuenta {
    private int nro;
    private String moneda;
    private double saldo;

    public Cuenta(int nro, String moneda) {
        this.nro = nro;
        this.moneda = moneda;
    }

    public void depositar(float monto){
        this.saldo += monto;
    }
    
    public void debitar(float monto){
        if(monto <= this.saldo){
            this.saldo -= monto;
        } else {
            System.out.println("Saldo Insuficiente!!");
        }
    }
    
    @Override
    public String toString() {
        return "Cuenta{" + "nro=" + nro + ", moneda=" + moneda + ", saldo=" + saldo + '}';
    }

    public int getNro() {
        return nro;
    }

    public String getMoneda() {
        return moneda;
    }

    public double getSaldo() {
        return saldo;
    }
 
}