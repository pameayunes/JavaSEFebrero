package ar.com.eduit.curso.java.interfaces;

public interface I_File {
    
    /*
    Interfaces en Java.
    - No tienen atributos ni constructores.
    - Todos sus miembros son publicos.
    - Puede tener constantes (final)
    - Puede contener métodos abstractos.
    - Una clase puede implementar muchas interfaces.
    */
    
    String getText();
    void setText(String text);
    
    /*
    Métodos default java8
    - Los métodos default son métodos que tienen cuerpo(código)
    */
    default void info(){
        System.out.println("Interface I_File");
    }
}