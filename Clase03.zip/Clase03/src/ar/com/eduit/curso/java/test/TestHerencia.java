package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.Cliente;
import ar.com.eduit.curso.java.entities.Cuenta;
import ar.com.eduit.curso.java.entities.Direccion;
import ar.com.eduit.curso.java.entities.Persona;
import ar.com.eduit.curso.java.entities.Vendedor;

public class TestHerencia {
    public static void main(String[] args) {
        System.out.println("-- dir1 --");
        Direccion dir1 = new Direccion("Medrano", 162, "1", "a");
        System.out.println(dir1);
        
        System.out.println("-- dir2 --");
        Direccion dir2 = new Direccion("Belgrano", 41, null, null, "Morón");
        System.out.println(dir2);
        
        /*
        System.out.println("-- persona1 --");
        Persona persona1=new Persona("Ana", 26, dir2);
        System.out.println(persona1);
        persona1.saludar();
        
        System.out.println("-- persona2 --");
        Persona persona2=new Persona("Diego",23,new Direccion("Larrea", 233, "4", "e"));
        System.out.println(persona2);
        persona2.saludar();
        
        System.out.println("-- persona3 --");
        Persona persona3=new Persona("Debora",22,persona2.getDireccion());
        System.out.println(persona3);
        persona3.saludar();
        */        

        
        System.out.println("-- vendedor1 --");
        Vendedor vendedor1=new Vendedor("Gabriela", 34, dir2, 1, 2000000);
        System.out.println(vendedor1);
        vendedor1.saludar();
        
                
        System.out.println("-- cuenta1 --");
        Cuenta cuenta1 = new Cuenta(1, "arg$");
        cuenta1.depositar(40000);
        cuenta1.depositar(50000);
        cuenta1.debitar(23000);
        System.out.println(cuenta1);
        
        System.out.println("-- cuenta2 --");
        Cuenta cuenta2=new Cuenta(2,"arg$");
        cuenta2.depositar(20000);
        cuenta2.debitar(2000);
        cuenta2.debitar(300000);
        System.out.println(cuenta2);
        
        
        System.out.println("-- cliente1 --");
        Cliente cliente1=new Cliente("LAutaro", 40, dir2, 1, cuenta2);
        cliente1.getCuenta().debitar(2000);
        System.out.println(cliente1);
        cliente1.saludar();
        
        
        // Poliformismo - Polimorfismo
        Object o=cuenta1;
        Persona p1=new Vendedor("Matias", 40, dir2, 20, 3333330);
        Persona p2=new Cliente("Susana", 22, dir1, 30, cuenta2);
        
        p1.saludar();
        p2.saludar();
        
        //casteo
        Vendedor v1=(Vendedor)p2;
        Vendedor v2=(p2 instanceof Vendedor)?(Vendedor)p2:null;
        
        
    }
}