package ar.com.eduit.curso.java.exceptions;

public class NoHayMasPasajesException extends Exception{
	private String nombreVuelo;
	private int pasajesDisponibles;
	private int pasajesPedidos;

	public NoHayMasPasajesException(String nombreVuelo, int pasajesDisponibles, int pasajesPedidos) {
		this.nombreVuelo = nombreVuelo;
		this.pasajesDisponibles = pasajesDisponibles;
		this.pasajesPedidos = pasajesPedidos;
	}
	
	@Override
	public String toString() {
		return "El vuelo "+nombreVuelo+", no tiene "+pasajesPedidos+" pasajes, solo tiene "+pasajesDisponibles;
	}

	@Override
	public String getMessage() {
		return "El vuelo "+nombreVuelo+", no tiene "+pasajesPedidos+" pasajes, solo tiene "+pasajesDisponibles;
	}

	public String getNombreVuelo() {
		return nombreVuelo;
	}

	public int getPasajesDisponibles() {
		return pasajesDisponibles;
	}

	public int getPasajesPedidos() {
		return pasajesPedidos;
	}

}
