package ar.com.eduit.curso.java.files;

import ar.com.eduit.curso.java.interfaces.I_File;

public class FileText implements I_File {

	@Override
	public String getText() {
		return "Texto de Archivo de texto!!";
	}

	@Override
	public void setText(String text) {
		System.out.println("Escribiendo Archivo de texto!!");
		
	}

}
