package ar.com.eduit.curso.java.interfaces;

import java.io.File;

public abstract class A_File {
    private File file;

    public A_File(File file) {
        this.file = file;
    }
    
    public abstract String getText();
    public abstract void setText(String text);
}