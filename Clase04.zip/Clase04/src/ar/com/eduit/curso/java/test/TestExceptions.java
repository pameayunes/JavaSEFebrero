package ar.com.eduit.curso.java.test;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import ar.com.eduit.curso.java.entidades.Vuelo;
import ar.com.eduit.curso.java.exceptions.NoHayMasPasajesException;
import ar.com.eduit.curso.java.utils.GeneradorDeExceptions;
import ar.com.eduit.curso.java.utils.Lector;

public class TestExceptions {
	public static void main(String[] args){
		//System.out.println(10/0);
		//System.out.println("Esta linea no se ejecuta!!!");
		
		/*
		 	Manejo de Exceptions
		 	
		 	Estructura Try - Catch - Finally
		 	
		 	try {						Obligatorio
		 		- Colocar las sentencias que pueden lanzar una exception.
		 		- Estas sentencias tienen más costo de hard.
		 		- Si se puede el bloque se ejecuta normalmente.
		 		- Si ocurre una exception se detiene el bloque 
		 			y toma el control el control el bloque catch.
		 	} catch(Exception e){		Obligatorio
		 		- Este bloque se ejecuta en caso de Exception en el bloque try.
		 		- No se detiene programa.
		 		- Se recibe como parametro un objeto de la clase Exception, 
		 			que contiene el detalle de la exception.
		 	} finally {					Opcional
		 		- Este bloque se ejecuta siempre ocurra Exception o no.
		 		- Las variables declaradas en try o catch estan fuera de scope.
		 	}
		 	El programa termina normalmente.
		 
		 */
		
		/*
		try {
			System.out.println(10/0); 		//Lanza una exception
			System.out.println("Esta linea no se ejecuta!!");
		} catch (Exception e) {
			System.out.println("Ocurrio un error!!");
			System.out.println(e);
		} finally {
			System.out.println("Este bloque se ejecuta siempre.");
		}
		System.out.println("El programa termina normalmente!");
		*/
		
		//FileReader file=new FileReader(new File("texto.txt"));

		/*
		try {
			//GeneradorDeExceptions.generar();
			//GeneradorDeExceptions.generar(true);
			//GeneradorDeExceptions.generar("26 ");
			//GeneradorDeExceptions.generar(null,2);
			//GeneradorDeExceptions.generar("hola",20);
			FileReader file=new FileReader(new File("texto.txt"));
			System.out.println("Esta linea no se ejecuta!");
		} catch (Exception e) {
			System.out.println(e);
		}
		*/
		
		
		
		//captura personalizada de exceptions
		try {
			//GeneradorDeExceptions.generar("Hola",23);
			FileReader file=new FileReader(new File("texto2.txt"));
		} catch (ArithmeticException e) 			{ System.out.println("División / 0!");
		//} catch (
		} catch (NumberFormatException e)			{ System.out.println("Formato de número incorrecto!");
		} catch (NullPointerException e)			{ System.out.println("Puntero Nulo!");
		//} catch (StringIndexOutOfBoundsException e)	{ System.out.println("Indice fuera de rango!");
		//} catch (StringIndexOutOfBoundsException | ArrayIndexOutOfBoundsException e)	{ System.out.println("Indice fuera de rango!");
		} catch (IndexOutOfBoundsException e)		{ System.out.println("Indice fuera de rango!");
		} catch (FileNotFoundException e)			{ System.out.println("Archivo no encontrado!");
		} catch (IOException e) 					{ System.out.println("Error IO!");
		} catch (Exception e) 						{ System.out.println("Ocurrio un error no esperado!"); }
		
		System.out.println("******************************************************************************");
		
		//Manejo de Exceptions para validar reglas de negocio
		Vuelo v1=new Vuelo("aer1234",100);
		Vuelo v2=new Vuelo("lat1111",100);
		
		try {
			v1.venderPasajes(150);
		} catch (NoHayMasPasajesException e) {
			System.out.println(e);
		}
			
		System.out.println("******************************************************************************");
		
		//try with resources jdk7
		
		/*
		 * Pesadilla - No Hacer esto
		try {
			Lector lector=new Lector("texto.txt");
			try {
				
				System.out.println(lector.read());
				lector.close();
			} catch (Exception e) {
				System.out.println(e);
				
			} finally {
				try {
					lector.close();
				}catch(Exception e) {
					System.out.println(e);
				}
			}
		}catch(Exception e) {
			System.out.println(e);
		}
		*/
		
		try (Lector lector=new Lector("texto.txt")){		//Try With Resources JDK 7 o superior.
			System.out.println(lector.read());
			//throw new Exception();
			//lector.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		
	}
}
