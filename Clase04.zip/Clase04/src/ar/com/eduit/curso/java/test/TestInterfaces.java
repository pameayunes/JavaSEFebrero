package ar.com.eduit.curso.java.test;

import java.util.Scanner;

import ar.com.eduit.curso.java.files.FileCloud;
import ar.com.eduit.curso.java.files.FileText;
import ar.com.eduit.curso.java.interfaces.I_File;

public class TestInterfaces {
	public static void main(String[] args) throws Exception {
		
		//inicialización
		I_File file=null;
		
		//file=new FileText();
		//file=new FileCloud();
		
		System.out.println("Ingrese 'FileText' o 'FileCloud': ");
		String input=new Scanner(System.in).next();
		
		//if(input.equalsIgnoreCase("FileText")) 	file=new FileText();
		//if(input.equalsIgnoreCase("FileCloud")) file=new FileCloud();
		
		//deprecado
		//file=(I_File)Class.forName("ar.com.eduit.curso.java.files."+input).newInstance();
		
		file=(I_File)Class
				.forName("ar.com.eduit.curso.java.files."+input)
				.getConstructor()
				.newInstance();
		
		//aplicación
		file.setText("hola");
		System.out.println(file.getText());
		file.info();
		
	}
}
