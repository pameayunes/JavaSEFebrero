package ar.com.eduit.curso.java.utils;

public class GeneradorDeExceptions {
	public static void generar() {
		int[] vector=new int[4];
		vector[10]=20;
	}
	public static void generar(boolean x) {
		if(x) System.out.println(10/0);
	}
	public static void generar(String number) {			//"26x"
		int nro=Integer.parseInt(number);
	}
	public static void generar(String texto,int index) {	//"hola",2
		//if(texto==null || index<0 || index>=texto.length()) return;
		System.out.println(texto.charAt(index));
	}
}
