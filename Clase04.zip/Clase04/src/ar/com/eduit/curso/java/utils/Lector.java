package ar.com.eduit.curso.java.utils;

import java.io.Closeable;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Lector implements Closeable{
	private File file;
	private FileReader in;

	public Lector(File file) throws FileNotFoundException{
		this.file = file;
		in=new FileReader(file);
	}
	
	public Lector(String file) throws FileNotFoundException {
		this.file = new File(file);
		in=new FileReader(file);
	}
	
	public String read() throws IOException {
		return ((char)in.read())+"";
	}

	@Override
	public void close() throws IOException {
		in.close();
		System.out.println("Se cerro la conexión");
	}

}
