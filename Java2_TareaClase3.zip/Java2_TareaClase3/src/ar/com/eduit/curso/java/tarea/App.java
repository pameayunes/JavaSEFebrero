
package ar.com.eduit.curso.java.tarea;

import java.util.HashSet;
import java.util.Set;


/**
 *
 * @author pame_
 */
public class App {
    public static void main (String[] args){
        Radio r1 = new Radio("Sony", "2019");
        //Radio r2 = new Radio ("Chancleta", "2000");
        Radio r3 = new Radio ("Ultra", "2020");
        AutoClasico auto1 = new AutoClasico("Ford", "2019", "abc 123", "verde");
        System.out.println(auto1);
        //System.out.println(auto1.getRadio());
        auto1.setRadio("Sony", "2000");
        System.out.println(auto1.getRadio());
        //AutoNuevo auto2 = new AutoNuevo("Fiat", "2021", "abc 234", "blanco", "Chancleta", "2020");
        //System.out.println(auto2);
        //auto2.setRadio("Ultra", "2020");
        //System.out.println(auto2);
        
    } 
}
