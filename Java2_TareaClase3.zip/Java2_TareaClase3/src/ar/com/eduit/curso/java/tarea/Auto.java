
package ar.com.eduit.curso.java.tarea;

/**
 *
 * @author pame_
 */
public abstract class Auto {
    protected String marca;
    protected String modelo;
    protected String patente;
    protected String color;

    public Auto(String marca, String modelo, String patente, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.patente = patente;
        this.color = color;
    }

    @Override
    public String toString() {
        return "Auto{" + "marca=" + marca + ", modelo=" + modelo + ", patente=" + patente + ", color=" + color + '}';
    }
    
      
    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public String getPatente() {
        return patente;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
    
    
}
