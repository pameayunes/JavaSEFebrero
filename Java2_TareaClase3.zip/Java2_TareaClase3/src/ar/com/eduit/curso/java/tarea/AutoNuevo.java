/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.eduit.curso.java.tarea;

/**
 *
 * @author pame_
 */
public class AutoNuevo extends Auto {
    private Radio radio;

    //CORREGIR, ESTE CONSTRUCTOR SIGNIFICA QUE PUEDE HABER VARIOS AUTOS CON LA MISMA RADIO
    //public AutoNuevo(String marca, String modelo, String patente, String color, Radio radio) {
      //  super(marca, modelo, patente, color);
        //this.radio = radio;
    //}
    
    public AutoNuevo(String marca, String modelo, String patente, String color, String Rmarca, String Rmodelo){
        super(marca, modelo, patente, color);
        this.radio = new Radio(Rmarca, Rmodelo);
        
    }
    
    @Override
    public String toString() {
        return "Auto{" + "marca=" + marca + ", modelo=" + modelo + ", patente=" + patente + ", color=" + color + ", radio= Rmarca" + radio + '}';
    }

    public Radio getRadio() {
        return radio;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public String getPatente() {
        return patente;
    }

    public String getColor() {
        return color;
    }
    
    //Para cambiar la radio al auto nuevo
    /*public void setRadio(String Rmarca, String Rmodelo) {
        this.radio = new Radio(Rmarca, Rmodelo);
    }*/

    public void setRadio(Radio radio) {
        this.radio = radio;
    }
    
    

    
   
    
    
       
    
}
