/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.eduit.curso.java.tarea;

/**
 *
 * @author pame_
 */
public class Radio {
    private String Rmarca;
    private String Rmodelo;

    public Radio(String marca, String modelo) {
        this.Rmarca = Rmarca;
        this.Rmodelo = Rmodelo;
    }

    @Override
    public String toString() {
        return "Radio{" + "marca=" + Rmarca + ", modelo=" + Rmodelo + '}';
    }
    
    
}
